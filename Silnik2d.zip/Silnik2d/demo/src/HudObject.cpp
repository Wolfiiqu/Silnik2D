#include "../demo/include/HudObject.h"
#include "../demo/include/Game.h"
#include "../demo/include/GameConfig.h"
#include <string>

namespace game {

HudObject::HudObject(const Game* g) : game(g) {
    fontLoaded = font.loadFromFile("assets/font.ttf");
    heartLoaded = heartTexture.loadFromFile("assets/heart.png");
    if (heartLoaded) {
        heartTexture.setSmooth(false); // ostre piksele dla pixel artu
    }
}

void HudObject::drawFallbackHeart(sf::RenderWindow& window, float x, float y, float size, sf::Color color) {
    float r = size * 0.28f;

    sf::CircleShape leftLobe(r);
    leftLobe.setFillColor(color);
    leftLobe.setPosition(x + size * 0.05f, y + size * 0.1f);

    sf::CircleShape rightLobe(r);
    rightLobe.setFillColor(color);
    rightLobe.setPosition(x + size * 0.42f, y + size * 0.1f);

    sf::ConvexShape bottom;
    bottom.setPointCount(3);
    bottom.setPoint(0, sf::Vector2f(x + size * 0.07f, y + size * 0.45f));
    bottom.setPoint(1, sf::Vector2f(x + size * 0.96f, y + size * 0.45f));
    bottom.setPoint(2, sf::Vector2f(x + size * 0.515f, y + size * 0.95f));
    bottom.setFillColor(color);

    window.draw(leftLobe);
    window.draw(rightLobe);
    window.draw(bottom);
}

void HudObject::draw(sf::RenderWindow& window) {
    if (!game) return;

    if (game->getState() == GameState::MENU) return;
    if (game->getState() == GameState::GAMEOVER) return;

    // === ŻYCIA (SERDUSZKA) ===
    int lives = game->getPlayerLives();
    int maxLives = GameConfig::PLAYER_LIVES; // np. 3
    float heartSize = 28.0f;
    float spacing = 8.0f;
    float startX = GameConfig::BOARD_X;
    float startY = GameConfig::BOARD_Y - 38.0f;

    for (int i = 0; i < maxLives; ++i) {
        float hx = startX + i * (heartSize + spacing);
        bool active = (i < lives);

        if (heartLoaded) {
            sf::Sprite heartSprite(heartTexture);
            sf::Vector2u texSize = heartTexture.getSize();
            heartSprite.setScale(heartSize / texSize.x, heartSize / texSize.y);
            heartSprite.setPosition(hx, startY);
            // Utracone życie jest przyciemnione / półprzezroczyste
            heartSprite.setColor(active ? sf::Color::White : sf::Color(80, 80, 80, 120));
            window.draw(heartSprite);
        } else {
            sf::Color c = active ? sf::Color(235, 45, 75) : sf::Color(70, 70, 80);
            drawFallbackHeart(window, hx, startY, heartSize, c);
        }
    }

    // === PUNKTACJA ===
    if (fontLoaded) {
        sf::Text scoreText;
        scoreText.setFont(font);
        scoreText.setCharacterSize(24);
        scoreText.setFillColor(sf::Color(255, 200, 0));
        scoreText.setPosition(GameConfig::BOARD_X + GameConfig::BOARD_W - 200,
                              GameConfig::BOARD_Y - 40);
        scoreText.setString("Punkty: " + std::to_string(game->getScore()));
        window.draw(scoreText);
    }

    // === GAME OVER ===
    if (game->isGameOver() && fontLoaded) {
        sf::Text goText;
        goText.setFont(font);
        goText.setCharacterSize(48);
        goText.setFillColor(sf::Color(255, 50, 50));
        goText.setString("GAME OVER");
        sf::FloatRect bounds = goText.getLocalBounds();
        goText.setPosition(
            GameConfig::BOARD_X + GameConfig::BOARD_W / 2 - bounds.width / 2,
            GameConfig::BOARD_Y + GameConfig::BOARD_H / 2 - bounds.height / 2 - 30
        );
        window.draw(goText);

        sf::Text restartText;
        restartText.setFont(font);
        restartText.setCharacterSize(24);
        restartText.setFillColor(sf::Color(255, 255, 255));
        sf::FloatRect rb = restartText.getLocalBounds();
        restartText.setPosition(
            GameConfig::BOARD_X + GameConfig::BOARD_W / 2 - rb.width / 2,
            GameConfig::BOARD_Y + GameConfig::BOARD_H / 2 + 30
        );
        window.draw(restartText);
    }
}

}
var classgame_1_1_tracker_bullet =
[
    [ "TrackerBullet", "classgame_1_1_tracker_bullet.html#acf4e615b277bce890b9d06d6d6ff3baf", null ],
    [ "update", "classgame_1_1_tracker_bullet.html#af90fbd9bbc8c68ec749a9e513daf0822", null ]
];
var classgame_1_1_bullet =
[
    [ "Bullet", "classgame_1_1_bullet.html#a855e400276337640afffc1a868e03fa5", null ],
    [ "collidesWith", "classgame_1_1_bullet.html#a4ffc9fa4a44a03c814fe32a7f95c20de", null ],
    [ "getCenter", "classgame_1_1_bullet.html#a7744530c77c7d00de36e7576be5e9517", null ],
    [ "isAlive", "classgame_1_1_bullet.html#ac94bb3e698185e4a40613fb4ce1b0ff4", null ],
    [ "isDead", "classgame_1_1_bullet.html#aa0847c40bd0ddd5d77b04830bdde8f70", null ],
    [ "isOffBoard", "classgame_1_1_bullet.html#ad228c6ec0f8a927f55d40ca147aebf9e", null ],
    [ "kill", "classgame_1_1_bullet.html#aa882970697611d4076a28cf537a60c3b", null ],
    [ "scaleVelocity", "classgame_1_1_bullet.html#aea1dd1b08209af6dac3bfedf236db2e2", null ],
    [ "update", "classgame_1_1_bullet.html#a2ebe4406ea2e9a0375f42f8513a66cf2", null ],
    [ "dead", "classgame_1_1_bullet.html#a7caf2d58b870d9c876de82b62e814aa1", null ],
    [ "lifetime", "classgame_1_1_bullet.html#a2d39a04595124c332bbed23d6bd02fcc", null ],
    [ "offBoard", "classgame_1_1_bullet.html#a2f8ef301a4ed88f6866726d23b899830", null ],
    [ "offBoardTime", "classgame_1_1_bullet.html#a0385f5b9525562021d550067b9e7023f", null ],
    [ "velocity", "classgame_1_1_bullet.html#afe809c77866c220b9db3cf994a7b053c", null ]
];
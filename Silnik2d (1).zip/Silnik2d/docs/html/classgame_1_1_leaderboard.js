var classgame_1_1_leaderboard =
[
    [ "Leaderboard", "classgame_1_1_leaderboard.html#aeb8c4e5a00095255a52d54ff86e4674c", null ],
    [ "addScore", "classgame_1_1_leaderboard.html#ae880901619c7b9eb2dcb1d9ea58d4e30", null ],
    [ "getScores", "classgame_1_1_leaderboard.html#a245f8b4bc0ae0c9c633750ab6616ecab", null ],
    [ "load", "classgame_1_1_leaderboard.html#ae140028215444bf6923d1b5187ffd775", null ],
    [ "save", "classgame_1_1_leaderboard.html#af86978b1b2f9e3cdd938540e7afe9e2d", null ]
];
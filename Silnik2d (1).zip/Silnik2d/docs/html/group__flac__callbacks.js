var group__flac__callbacks =
[
    [ "FLAC__IOCallbacks", "struct_f_l_a_c_____i_o_callbacks.html", null ],
    [ "FLAC__IOCallback_Close", "group__flac__callbacks.html#ga7b55c440229691d9539d19d963bc076e", null ],
    [ "FLAC__IOCallback_Eof", "group__flac__callbacks.html#ga9f238b5e35696d3cd4d4683f34f13abf", null ],
    [ "FLAC__IOCallback_Read", "group__flac__callbacks.html#gaaaced5bb80662da8a6286e1369ab0d53", null ],
    [ "FLAC__IOCallback_Seek", "group__flac__callbacks.html#gabd30216e0900f2eeb845f1e6fb7e6fc3", null ],
    [ "FLAC__IOCallback_Tell", "group__flac__callbacks.html#gaa0837adee42b5201070774e5948bc05c", null ],
    [ "FLAC__IOCallback_Write", "group__flac__callbacks.html#ga5da6e1a5b94e56769c64781fa48ef80a", null ],
    [ "FLAC__IOHandle", "group__flac__callbacks.html#ga4c329c3168dee6e352384c5e9306260d", null ]
];
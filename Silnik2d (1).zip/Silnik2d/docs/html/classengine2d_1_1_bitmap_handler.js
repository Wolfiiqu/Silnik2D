var classengine2d_1_1_bitmap_handler =
[
    [ "get", "classengine2d_1_1_bitmap_handler.html#ae4a1c993e17acb28b2e6c989078fc7b3", null ],
    [ "load", "classengine2d_1_1_bitmap_handler.html#abb1b340f17efb5f29be52a91992ddebd", null ],
    [ "unload", "classengine2d_1_1_bitmap_handler.html#a03cc45d411f357c614184fec725f7206", null ]
];
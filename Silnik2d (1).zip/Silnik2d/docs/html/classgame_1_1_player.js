var classgame_1_1_player =
[
    [ "Player", "classgame_1_1_player.html#a1a9ff754931046ffadf47f1c7a209899", null ],
    [ "~Player", "classgame_1_1_player.html#ab9514317adcbecdb0d22cb2f7293ac61", null ],
    [ "draw", "classgame_1_1_player.html#a8f9727a3dfe9216995fc14bc79247acf", null ],
    [ "getCenter", "classgame_1_1_player.html#aa46508c7ceb5f78d316276dab9283f3b", null ],
    [ "getHitbox", "classgame_1_1_player.html#affff6a83697c4ab12193dc3b56345694", null ],
    [ "getLives", "classgame_1_1_player.html#ad33e93b363da646baf366dbcdc7161bf", null ],
    [ "hitboxCollidesCircle", "classgame_1_1_player.html#aa670e99b0e001594c8fc1cdabb711ae0", null ],
    [ "hitboxContains", "classgame_1_1_player.html#a38cccb056c25016da8d81c5bd8b4a075", null ],
    [ "isInvincible", "classgame_1_1_player.html#ac6699926c3ffb38c837e628d66a3cd33", null ],
    [ "isVisibleBlink", "classgame_1_1_player.html#aa67e58922bd87bf63e01c237c9c64f20", null ],
    [ "reset", "classgame_1_1_player.html#a24d06d279cbd24f0cdb631a68d63455d", null ],
    [ "takeDamage", "classgame_1_1_player.html#a8ccc049f8dd0f8b92f720895d3952afb", null ],
    [ "update", "classgame_1_1_player.html#a32cf71510f29dd071831f9e1b341b3a9", null ]
];
var classengine2d_1_1_ellipse =
[
    [ "Ellipse", "classengine2d_1_1_ellipse.html#a3bb9d099782bd1847abe0f866fe4c68c", null ],
    [ "draw", "classengine2d_1_1_ellipse.html#ab40e25cbfbbaa88c1f2509822b0cc887", null ],
    [ "setRadii", "classengine2d_1_1_ellipse.html#a0e7b0254570587cd151e291c26c4c087", null ]
];
var classsf_1_1_http =
[
    [ "Request", "classsf_1_1_http_1_1_request.html", "classsf_1_1_http_1_1_request" ],
    [ "Response", "classsf_1_1_http_1_1_response.html", "classsf_1_1_http_1_1_response" ],
    [ "Http", "classsf_1_1_http.html#abe2360194f99bdde402c9f97a85cf067", null ],
    [ "Http", "classsf_1_1_http.html#a79efd844a735f083fcce0edbf1092385", null ],
    [ "sendRequest", "classsf_1_1_http.html#a4fc21ca5c3bef73d36355def96ee27c0", null ],
    [ "setHost", "classsf_1_1_http.html#a55121d543b61c41cf20b885a97b04e65", null ]
];
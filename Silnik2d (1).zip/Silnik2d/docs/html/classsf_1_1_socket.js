var classsf_1_1_socket =
[
    [ "Status", "classsf_1_1_socket.html#a51bf0fd51057b98a10fbb866246176dc", [
      [ "Done", "classsf_1_1_socket.html#a51bf0fd51057b98a10fbb866246176dca1de3a85bc56d3ae85b3d0f3cfd04ae90", null ],
      [ "NotReady", "classsf_1_1_socket.html#a51bf0fd51057b98a10fbb866246176dca8554848daae98f996e131bdeed076c09", null ],
      [ "Partial", "classsf_1_1_socket.html#a51bf0fd51057b98a10fbb866246176dca181c163fad2eaea927185d127c392706", null ],
      [ "Disconnected", "classsf_1_1_socket.html#a51bf0fd51057b98a10fbb866246176dcab215141f756acdc23c67fad149710eb1", null ],
      [ "Error", "classsf_1_1_socket.html#a51bf0fd51057b98a10fbb866246176dca1dc9854433a28c22e192721179a2df5d", null ]
    ] ],
    [ "Type", "classsf_1_1_socket.html#a5d3ff44e56e68f02816bb0fabc34adf8", [
      [ "Tcp", "classsf_1_1_socket.html#a5d3ff44e56e68f02816bb0fabc34adf8acc02e97e90234b957eaad4dff7f22214", null ],
      [ "Udp", "classsf_1_1_socket.html#a5d3ff44e56e68f02816bb0fabc34adf8a6ebf3094830db4820191a327f3cc6ce2", null ]
    ] ],
    [ "~Socket", "classsf_1_1_socket.html#afdfad4a45ccdd041bb0c6ed8a61f4c84", null ],
    [ "Socket", "classsf_1_1_socket.html#a80ffb47ec0bafc83af019055d3e6a303", null ],
    [ "close", "classsf_1_1_socket.html#a71f2f5c2aa99e01cafe824fee4c573be", null ],
    [ "create", "classsf_1_1_socket.html#aafbe140f4b1921e0d19e88cf7a61dcbc", null ],
    [ "create", "classsf_1_1_socket.html#af1dd898f7aa3ead7ff7b2d1c20e97781", null ],
    [ "getHandle", "classsf_1_1_socket.html#a675457784284ae2f5640bbbe16729393", null ],
    [ "isBlocking", "classsf_1_1_socket.html#ab1ceca9ac114b8baeeda3b34a0aca468", null ],
    [ "setBlocking", "classsf_1_1_socket.html#a165fc1423e281ea2714c70303d3a9782", null ]
];
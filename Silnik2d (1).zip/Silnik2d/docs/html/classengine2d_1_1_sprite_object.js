var classengine2d_1_1_sprite_object =
[
    [ "addFrame", "classengine2d_1_1_sprite_object.html#a519f2424b88c22f7ce0aa2e1c71a7e5d", null ],
    [ "animate", "classengine2d_1_1_sprite_object.html#ac6d62039e3d4d5231b3eb21fdd2bb627", null ],
    [ "draw", "classengine2d_1_1_sprite_object.html#a4ffcce4f400aad814ef8a8cb0e32f96f", null ],
    [ "setFrameTime", "classengine2d_1_1_sprite_object.html#a4394bfdcb05fdf9fdbe8c5b56f04dcb0", null ],
    [ "currentFrame", "classengine2d_1_1_sprite_object.html#a7280e4f21c3e74f4ae327883985681de", null ],
    [ "elapsed", "classengine2d_1_1_sprite_object.html#abc322e3cfe4b74d924552eb910426898", null ],
    [ "frames", "classengine2d_1_1_sprite_object.html#ac32342178921bf489012543f2a0d8b92", null ],
    [ "frameTime", "classengine2d_1_1_sprite_object.html#a6d9ba71be9ff9bc4e465e828d5f58b0a", null ],
    [ "loop", "classengine2d_1_1_sprite_object.html#aa78c8b88b8e7c54f9ffe6d78973ec680", null ]
];
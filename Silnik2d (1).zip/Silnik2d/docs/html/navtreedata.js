/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Silnik2D", "index.html", [
    [ "SFML Documentation", "index.html", "index" ],
    [ "Changelog", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html", [
      [ "SFML 2.6.1", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md1", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md2", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md3", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md4", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md5", null ]
      ] ],
      [ "SFML 2.6.0", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md6", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md7", null ],
        [ "System", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md8", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md9", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md10", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md11", null ],
        [ "Networking", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md12", null ]
      ] ],
      [ "SFML 2.5.1", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md13", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md14", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md15", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md16", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md17", null ]
      ] ],
      [ "SFML 2.5.0", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md18", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md19", null ],
        [ "System", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md20", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md21", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md22", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md23", null ],
        [ "Network", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md24", null ]
      ] ],
      [ "SFML 2.4.2", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md25", [
        [ "System", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md26", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md27", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md28", null ]
      ] ],
      [ "SFML 2.4.1", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md29", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md30", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md31", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md32", null ],
        [ "Network", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md33", null ]
      ] ],
      [ "SFML 2.4.0", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md34", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md35", null ],
        [ "Deprecated API", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md36", null ],
        [ "System", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md37", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md38", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md39", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md40", null ],
        [ "Network", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md41", null ]
      ] ],
      [ "SFML 2.3.2", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md42", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md43", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md44", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md45", null ]
      ] ],
      [ "SFML 2.3.1", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md46", [
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md47", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md48", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md49", null ]
      ] ],
      [ "SFML 2.3", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md50", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md51", null ],
        [ "Deprecated API", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md52", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md53", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md54", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md55", null ],
        [ "Network", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md56", null ]
      ] ],
      [ "SFML 2.2", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md57", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md58", null ],
        [ "System", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md59", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md60", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md61", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md62", null ],
        [ "Network", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md63", null ]
      ] ],
      [ "SFML 2.1", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md64", [
        [ "General", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md65", null ],
        [ "Window", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md66", null ],
        [ "Graphics", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md67", null ],
        [ "Audio", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md68", null ],
        [ "Network", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md69", null ]
      ] ],
      [ "SFML 2.0", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md70", null ],
      [ "Older Releases", "md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md71", null ]
    ] ],
    [ "Contribution Guidelines", "md_cmake-build-debug_2__deps_2sfml-src_2_c_o_n_t_r_i_b_u_t_i_n_g.html", null ],
    [ "Assets used by SFML's example projects.", "md_cmake-build-debug_2__deps_2sfml-src_2examples_2asset__licenses.html", null ],
    [ "SFML", "md_cmake-build-debug_2__deps_2sfml-src_2license.html", [
      [ "External libraries used by SFML", "md_cmake-build-debug_2__deps_2sfml-src_2license.html#autotoc_md75", null ]
    ] ],
    [ "Lista elementów do wycofania", "deprecated.html", null ],
    [ "Sekcje", "topics.html", "topics" ],
    [ "Przestrzenie nazw", "namespaces.html", [
      [ "Lista przestrzeni nazw", "namespaces.html", "namespaces_dup" ],
      [ "Składowe przestrzeni nazw", "namespacemembers.html", [
        [ "Wszystko", "namespacemembers.html", null ],
        [ "Funkcje", "namespacemembers_func.html", null ],
        [ "Zmienne", "namespacemembers_vars.html", null ],
        [ "Definicje typów", "namespacemembers_type.html", null ],
        [ "Wyliczenia", "namespacemembers_enum.html", null ],
        [ "Wartości wyliczeń", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Klasy", "annotated.html", [
      [ "Lista klas", "annotated.html", "annotated_dup" ],
      [ "Indeks klas", "classes.html", null ],
      [ "Hierarchia klas", "hierarchy.html", "hierarchy" ],
      [ "Składowe klas", "functions.html", [
        [ "Wszystko", "functions.html", "functions_dup" ],
        [ "Funkcje", "functions_func.html", "functions_func" ],
        [ "Zmienne", "functions_vars.html", "functions_vars" ],
        [ "Definicje typów", "functions_type.html", null ],
        [ "Wyliczenia", "functions_enum.html", null ],
        [ "Wartości wyliczeń", "functions_eval.html", "functions_eval" ],
        [ "Właściwości", "functions_prop.html", null ],
        [ "Powiązane symbole", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Pliki", "files.html", [
      [ "Lista plików", "files.html", "files_dup" ],
      [ "Składowe plików", "globals.html", [
        [ "Wszystko", "globals.html", null ],
        [ "Funkcje", "globals_func.html", null ],
        [ "Definicje", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"__mingw__dxhelper_8h_source.html",
"_system_8hpp_source.html",
"classengine2d_1_1_point2_d.html#ae9a3b5bfaeb29568c17f168330f6c1f2",
"classsf_1_1_drawable.html",
"classsf_1_1_joystick.html#a48db337092c2e263774f94de6d50baa7a51ef1455f7511ad4a78ba241d66593ce",
"classsf_1_1_render_target.html#a2997c96cbd93cb8ce0aba2ddae35b86f",
"classsf_1_1_sound_stream.html#a9c351711198ee1aa77c2fefd3ced4d2c",
"classsf_1_1_transform.html#ac32de51bd0b9f3d52fbe0838225ee83b",
"classsf_1_1priv_1_1_cursor_impl.html#a0b4f3a8c6739a7d9b913583c8f7bf8da",
"classsf_1_1priv_1_1_thread_local_impl.html#a38c4e5663e724d06a8e1d946c4a1040e",
"examples_2_x11_2gl_8h_source.html",
"group__flac__format.html#ga5f1c1d7e3ddc533938b83951c7b3dda5",
"group__flac__metadata__level2.html#ga178898eef72ba9d569b1964fffcb4a8b",
"group__flac__stream__encoder.html#ga3bb869620af2b188d77982a5c30b047d",
"md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md20",
"struct_d_i_p_r_o_p_d_w_o_r_d.html",
"struct_vk_framebuffer_create_info.html",
"structovectl__ratemanage__arg.html",
"structsf_1_1_keyboard_1_1_scan.html#aa42fbf6954d6f81f7606e566c7abe875af003329d2c5a26d0262caf3ddef0a45e"
];

const SYNCONMSG = 'kliknij żeby wyłączyć pokazywanie otwartego elementu w drzewie zawartości';
const SYNCOFFMSG = 'kliknij żeby włączyć pokazywanie otwartego elementu w drzewie zawartości';
const LISTOFALLMEMBERS = 'Lista wszystkich składowych';
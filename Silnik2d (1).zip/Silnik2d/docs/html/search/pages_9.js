var searchData=
[
  ['c_20api_0',['C API',['../C:/Users/kacpe/OneDrive/Pulpit/moje/Silnik2D-main/Silnik2d/Silnik2d/cmake-build-debug/_deps/sfml-src/extlibs/headers/FLAC/all.h#c_api',1,'FLAC C API'],['../C:/Users/kacpe/OneDrive/Pulpit/moje/Silnik2D-main/Silnik2d/Silnik2d/cmake-build-debug/_deps/sfml-src/extlibs/headers/FLAC/all.h#cpp_api',1,'FLAC C++ API']]],
  ['changelog_1',['Changelog',['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html',1,'']]],
  ['contribute_2',['Contribute',['../dir_3ff134045e9dc415d49869049c3f7e67.html#autotoc_md81',1,'']]],
  ['contribution_20guidelines_3',['Contribution Guidelines',['../md_cmake-build-debug_2__deps_2sfml-src_2_c_o_n_t_r_i_b_u_t_i_n_g.html',1,'']]]
];

var searchData=
[
  ['deprecated_20api_0',['Deprecated API',['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md36',1,'Deprecated API'],['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md52',1,'Deprecated API']]],
  ['developers_1',['Embedded Developers',['../C:/Users/kacpe/OneDrive/Pulpit/moje/Silnik2D-main/Silnik2d/Silnik2d/cmake-build-debug/_deps/sfml-src/extlibs/headers/FLAC/all.h#embedded_developers',1,'']]],
  ['do_20wycofania_2',['Lista elementów do wycofania',['../deprecated.html',1,'']]],
  ['documentation_3',['SFML Documentation',['../index.html',1,'']]],
  ['download_4',['Download',['../dir_3ff134045e9dc415d49869049c3f7e67.html#autotoc_md78',1,'']]]
];

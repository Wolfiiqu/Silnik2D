var searchData=
[
  ['elementów_20do_20wycofania_0',['Lista elementów do wycofania',['../deprecated.html',1,'']]],
  ['embedded_20developers_1',['Embedded Developers',['../C:/Users/kacpe/OneDrive/Pulpit/moje/Silnik2D-main/Silnik2d/Silnik2d/cmake-build-debug/_deps/sfml-src/extlibs/headers/FLAC/all.h#embedded_developers',1,'']]],
  ['example_2',['Short example',['../index.html#example',1,'']]],
  ['example_20projects_3',['Assets used by SFML&apos;s example projects.',['../md_cmake-build-debug_2__deps_2sfml-src_2examples_2asset__licenses.html',1,'']]],
  ['external_20libraries_20used_20by_20sfml_4',['External libraries used by SFML',['../md_cmake-build-debug_2__deps_2sfml-src_2license.html#autotoc_md75',1,'']]]
];

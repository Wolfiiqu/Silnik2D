var indexSectionsWithContent =
{
  0: "0123456[_abcdefghijklmnopqrstuvwxyz~—",
  1: "[_abcdefghijklmnoprstuvw",
  2: "s",
  3: "abcdeghilmprstuv",
  4: "abcdefghijklmnoprstuvwz~",
  5: "abcdefghijklmnopqrstuvwxyz",
  6: "bcfiv",
  7: "abcdefgkmpstuw",
  8: "abcdefghijklmnopqrstuvwxyz",
  9: "cmos",
  10: "o",
  11: "os",
  12: "01234_acdefghilmnopstvw",
  13: "0123456abcdefgilmnoprsuw—"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "related",
  11: "defines",
  12: "groups",
  13: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Definicje typów",
  7: "Wyliczenia",
  8: "Wartości wyliczeń",
  9: "Właściwości",
  10: "Przyjaciele",
  11: "Definicje",
  12: "Grupay",
  13: "Strony"
};


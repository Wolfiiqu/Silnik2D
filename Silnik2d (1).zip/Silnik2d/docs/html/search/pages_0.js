var searchData=
[
  ['0_0',['0',['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md70',1,'SFML 2.0'],['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md34',1,'SFML 2.4.0'],['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md18',1,'SFML 2.5.0'],['../md_cmake-build-debug_2__deps_2sfml-src_2changelog.html#autotoc_md6',1,'SFML 2.6.0']]]
];

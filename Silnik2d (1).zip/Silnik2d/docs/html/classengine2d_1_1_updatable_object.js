var classengine2d_1_1_updatable_object =
[
    [ "update", "classengine2d_1_1_updatable_object.html#a050631ed09371da013926f467e8cb817", null ]
];
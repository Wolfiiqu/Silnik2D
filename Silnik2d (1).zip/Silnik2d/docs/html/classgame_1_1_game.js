var classgame_1_1_game =
[
    [ "Game", "classgame_1_1_game.html#a74cd9697144c5bb5ccf1d2cb71d56e41", null ],
    [ "~Game", "classgame_1_1_game.html#a9fd96a37b55d908071105879d015df8c", null ],
    [ "getPlayerLives", "classgame_1_1_game.html#aa6a3f36b2887be3d4598603a15aeeaa5", null ],
    [ "getScore", "classgame_1_1_game.html#aa283d93843ad707060bd6511be127ace", null ],
    [ "getState", "classgame_1_1_game.html#a828961ece3c849db52af2ff523e6f5bc", null ],
    [ "getSurvivalTime", "classgame_1_1_game.html#adefbadad3c3b220bf6e406785efd8d6b", null ],
    [ "goToMenu", "classgame_1_1_game.html#a8680728ef56e0275e164d16717a49d32", null ],
    [ "isGameOver", "classgame_1_1_game.html#acf994c43057d70ce622b54459fa87e9c", null ],
    [ "run", "classgame_1_1_game.html#a670eb030b57c2cf9efbb039074d207b9", null ],
    [ "setState", "classgame_1_1_game.html#a5048d6874f2f26db2243f13e7f1c4a0a", null ],
    [ "startGame", "classgame_1_1_game.html#a8e89850b677cb74a78aae4f4d2c4fa30", null ]
];